%Intensity level with background
%Krisha Lakhani - 60001200097
r = imread ('cameraman.tif');
[row col]=size(r);
r1 = 50;
r2 =100;
s1 = 0;
s2 = 255;

m = 255/(r2-r1);
for i= 1:row;
    for j=1:col;
        if 0 < r(i,j)  && r(i,j)<r1
            s(i,j)=r(i,j);
        elseif r1<r(i,j) && r(i,j)<r2
            s(i,j)= 255;
        else r2<r(i,j)<255
            s(i,j) = r(i,j);
        end
    end
end
figure(1);
imshow(r);
figure(2);
imshow(uint8(s));
           
   
           