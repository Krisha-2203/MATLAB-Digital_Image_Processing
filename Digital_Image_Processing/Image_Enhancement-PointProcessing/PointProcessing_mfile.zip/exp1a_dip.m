%point process(negative transofrmation)
%Shobha Gupta - 60001200094
%Krisha Lakhani- 60001200097
a = imread ('cameraman.tif');
[r c] = size(a);
figure(1);
imshow(a);
b = 255-a;
figure(2);
imshow(b);