%contrast stretching
%Shobha Gupta - 60001200094
%Krisha Lakhani- 60001200097
close all;
r = imread ('cameraman.tif');

r1 = 50;
r2 = 100;
s1 = 25;
s2 = 200;

m1 = s1/r1 ;
m2 = (s2-s1)/(r2 - r1);
m3 = (255-s2)/(255-r2);

if 0<r<r1
   s = m1*r;
elseif r1<r<r2
    s = m2(r-r1)+s1;
else r2<r<255
    s = m3(r-r2)+s2;
end
 
figure(1);
imshow(r);
figure(2);
imshow(s);


