%thresholding(converts to binary)
%Krisha Lakhani-60001200097
r = imread ('cameraman.tif');
[row col]=size(r);
L=255;
rth=50;

for i= 1:row;
    for j=1:col;
        if r(i,j)<= rth;
            s(i,j)=0;
        else rth< r(i,j) && r(i,j)<255
            s(i,j)=L;

       end
    end
end

figure(1);
imshow(r);
figure(2);
imshow(s);