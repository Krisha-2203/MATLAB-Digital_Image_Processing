%clipping(removing noise)
%Shobha Gupta - 60001200094
%Krisha Lakhani- 60001200097
clear all;
close all;
clc;
a = imread ('cameraman.tif');
[r c] = size(a);
r1 = 50;
r2 = 100;
s1 = 0;
s2 = 255;

m = 255/(r2 - r1);
 for i=1:r
     for j = 1:c
if 0<a(i,j) && a(i,j)<r1
   s(i,j) = 0;
elseif r1<a(i,j) && a(i,j)<r2
    s(i,j) = m*(a(i,j));
else r2<a(i,j)<255
    s(i,j) = 255;
end
     end
 end
figure(1);
imshow(a);
figure(2);
imshow(uint8(s));
