%Experiment 7 - Morphological Operations (Boundary Extraction)
%Krisha Lakhani - 60001200097
clc;
clear all;
a = [
    0 0 0 0 0 0 0 0;
    0 0 0 0 0 0 0 0;
    0 0 1 1 1 1 0 0;
    0 1 1 1 1 1 0 0;
    0 1 1 1 1 1 1 1;
    0 1 1 1 1 1 1 1;
    0 0 1 1 1 1 1 1;
    0 0 0 0 0 0 0 0
];
st = [
     0 1 0;
     1 1 1;
     0 1 0
];
[x,y] = size(a);
e_a = zeros(x,y);
be = zeros(x,y);
for m = 1:x-2
    for n = 1:y-2
        if (a(m,n+1) == st(1,2) && a(m+1,n) == st(2,1) && a(m+1,n+1) == st(2,2) && a(m+1,n+2) == st(2,3) && a(m+2,n+1) == st(3,2))
            e_a(m+1,n+1) = 1;
        end
    end
end
be = a - e_a;
disp("Krisha Lakhani - 60001200097");
disp("Original:");
disp(a);
disp("Structuring element:");
disp(st);
disp("E(A):");
disp(e_a);
disp("After Boundary Extraction:");
disp(be);