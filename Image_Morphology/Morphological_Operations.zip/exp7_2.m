%Experiment 7 - Morphological Operations (Opening)
%Krisha Lakhani - 60001200097
clc;
clear all;
a = [
    0 0 0 0 0 0 0 0 0 0;
    0 0 0 0 0 0 0 0 0 0;
    0 1 1 1 0 0 1 1 1 0;
    0 1 1 1 0 0 1 1 1 0;
    0 1 1 1 1 1 1 1 1 0;
    0 1 1 1 0 0 1 1 1 0;
    0 1 1 1 0 0 1 1 1 0;
    0 0 0 0 0 0 0 0 0 0;
    0 0 0 0 0 0 0 0 0 0;
    0 0 0 0 0 0 0 0 0 0
];
st = [
     1;
     1
];
[x,y] = size(a);
e_a = zeros(x,y);
opening = zeros(x,y);
for m = 1:x-1
    for n = 1:y
        if (a(m,n) == st(1,1) && a(m+1,n) == st(2,1))
            e_a(m,n) = 1;
        end
    end
end
for i = 1:x-1
    for j = 1:y
        if (e_a(i,j) == st(1,1) || e_a(i+1,j) == st(2,1))
            opening(i,j) = 1;
        end
    end
end
disp("Krisha Lakhani - 60001200097");
disp("Original:");
disp(a);
disp("Structuring element:");
disp(st);
disp("E(A):");
disp(e_a);
disp("After Opening:");
disp(opening);